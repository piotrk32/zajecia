from enum import Enum


class EdgeType(Enum):
    directed = 1
    undirected = 2
